package com.tobin.fotofetcher;

public interface Interface {
    void itemClicked(int position);
    void updateTag(int position);
}
